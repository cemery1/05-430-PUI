# PUI-Lab7
A demo of Javascript object creation using a web app the shows new animals on every refresh of the page
